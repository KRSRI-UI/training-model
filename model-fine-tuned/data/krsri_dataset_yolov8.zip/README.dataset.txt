# krsri > versi 2 train val
https://universe.roboflow.com/boneka-krsri/krsri-fbpsv

Provided by a Roboflow user
License: CC BY 4.0

